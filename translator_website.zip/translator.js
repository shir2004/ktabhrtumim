// מילונים לתרגום
const hebrewToHieroglyphs = {
  א: "𓂀", ב: "𓃀", ג: "𓎼", ד: "𓂧", ה: "𓎛", ו: "𓇌", ז: "𓊃",
  ח: "𓉔", ט: "𓍿", י: "𓏭", כ: "𓎡", ל: "𓃭", מ: "𓅓", נ: "𓈖",
  ס: "𓋴", ע: "𓂝", פ: "𓊪", צ: "𓍿", ק: "𓎤", ר: "𓂋", ש: "𓋴", ת: "𓏏", ך: "𓎡", ם: "𓋔", ן: "𓈖"
};

const hieroglyphsToHebrew = Object.fromEntries(
  Object.entries(hebrewToHieroglyphs).map(([key, value]) => [value, key])
);

// פונקציה לתרגום מעברית לכתב חרטומים
function translateToHieroglyphs() {
  const input = document.getElementById("inputText").value.trim();
  let translatedText = "";

  for (let char of input) {
    if (hebrewToHieroglyphs[char]) {
      translatedText += hebrewToHieroglyphs[char]; // תרגום לאות חרטומים
    } else if (char === " ") {
      translatedText += " "; // שמירה על רווחים
    } else {
      translatedText += char; // אם התו לא נמצא במילון
    }
  }

  document.getElementById("outputText").innerText = translatedText;
}

// פונקציה לתרגום מכתב חרטומים לעברית
function translateToHebrew() {
  const input = document.getElementById("inputText").value.trim();
  let translatedText = "";

  for (let char of input) {
    if (hieroglyphsToHebrew[char]) {
      translatedText += hieroglyphsToHebrew[char]; // תרגום לאות עברית
    } else if (char === " ") {
      translatedText += " "; // שמירה על רווחים
    } else {
      translatedText += char; // אם התו לא נמצא במילון
    }
  }

  document.getElementById("outputText").innerText = translatedText;
}
